package com.example.cameraapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.firebase.database.*
import java.util.jar.Attributes

class SavingData : AppCompatActivity() {

    lateinit var editTextName: EditText
    lateinit var ratingBar: RatingBar
    lateinit var buttonSave: Button
    lateinit var listView: ListView

    lateinit var ratingList: MutableList<Hero>

    lateinit var ref: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saving_data)


        ratingList = mutableListOf()
        val ref = FirebaseDatabase.getInstance().getReference("ratings")


        editTextName = findViewById(R.id.editTextName)
        ratingBar = findViewById(R.id.ratingBar)
        buttonSave = findViewById(R.id.buttonSave)
        listView = findViewById(R.id.listView)

        buttonSave.setOnClickListener {
            saveRating()
        }

        ref.addValueEventListener(object: ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onDataChange(p0: DataSnapshot) {
                if (p0.exists()) {
                    ratingList.clear()
                    for (h in p0.children) {
                        val rating = h.getValue(Hero::class.java)
                        ratingList.add(rating!!)
                    }
                    val adapter = ratingAdapter (this@SavingData, R.layout.ratings, ratingList)
                    listView.adapter = adapter

                }

            }
        })

    }
    private fun saveRating() {
        val name = editTextName.text.toString().trim()

        if (name.isEmpty()) {
            editTextName.error = "Please enter a valid name"
            return
        }

        val ratingID = ref.push().key

        val hero = Hero(ratingID!!, name, ratingBar.rating.toInt())

        ref.child(ratingID).setValue(hero).addOnCompleteListener {
            Toast.makeText(applicationContext, "Rating saved succesfully", Toast.LENGTH_LONG).show()
        }

    }
}
