package com.example.cameraapp

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.firebase.database.FirebaseDatabase

@Suppress("UNREACHABLE_CODE")
class ratingAdapter (val mCtx: Context, val layoutResId: Int, val ratingList: List<Hero>)
    :ArrayAdapter<Hero>(mCtx, layoutResId, ratingList) {

    @SuppressLint("ViewHolder")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater : LayoutInflater = LayoutInflater.from(mCtx) ;
        val view: View = layoutInflater.inflate(layoutResId, null)

        val textViewName = view.findViewById<TextView>(R.id.textViewName)
        val textViewUpdate = view.findViewById<TextView>(R.id.TextViewUpdate)

        val rating = ratingList[position]

        textViewName.text = rating.name

        textViewUpdate.setOnClickListener {
            showUpdateDialog(rating)
        }

        return view
    }

    fun showUpdateDialog(rating: Hero) {
        val builder = AlertDialog.Builder(mCtx)
        builder.setTitle("Update Rating")

        val inflater = LayoutInflater.from(mCtx)

        val view = inflater.inflate(R.layout.layout_rating_update, null)

        val editText = view.findViewById<EditText>(R.id.editTextName)
        val ratingBar = view.findViewById<RatingBar>(R.id.ratingBar)

        editText.setText(rating.name)
        ratingBar.rating = rating.rating.toFloat()

        builder.setView(view)


        builder.setPositiveButton("Update", DialogInterface.OnCancelListener {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                val dbRating = FirebaseDatabase.getInstance().getReference("ratings")

                val name = editText.text.toString().trim()

                if (name.isEmpty()) {
                    editText.error = "Please enter a valid name"
                    editText.requestFocus()
                    return@OnCancelListener
                }

               val rating2 = Hero(rating.id, name, ratingBar.rating.toInt())

                dbRating.child(rating.id).setValue(rating2)

            Toast.makeText(mCtx, "Rating Updated", Toast.LENGTH_LONG).show()

        })

        builder.setNegativeButton("No", DialogInterface.OnCancelListener {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        })

        val alert = builder.create()
        alert.show()

    }

}

private fun AlertDialog.Builder.setNegativeButton(s: String, onCancelListener: DialogInterface.OnCancelListener) {

}

private fun AlertDialog.Builder.setPositiveButton(s: String, onCancelListener: DialogInterface.OnCancelListener) {

}
